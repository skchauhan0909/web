# TODO
 - [ ] fix center dots (navigational dots)
 - [ ] add support for diffrent transitions (currently only fade)
 - [ ] add some sort of support for customizing looks
 - [ ] add support for more elements inside the slideshow such as text etc
 - [ ] namespace everything (however you do that in js)
 - [ ] fix bug of first time a slide is changed not actually changing or fading (add the "not shown" option to everything except the last slide (or first))
 - [ ] add support for automatic transitions based on a timer
